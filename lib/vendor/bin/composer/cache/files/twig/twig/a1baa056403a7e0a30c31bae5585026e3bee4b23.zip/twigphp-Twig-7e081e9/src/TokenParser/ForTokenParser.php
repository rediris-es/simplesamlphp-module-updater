<?php

namespace Twig\TokenParser;

class_exists('Twig_TokenParser_For');

if (\false) {
    class ForTokenParser extends \Twig_TokenParser_For
    {
    }
}
