<?php

namespace Twig\TokenParser;

class_exists('Twig_TokenParser_Filter');

if (\false) {
    class FilterTokenParser extends \Twig_TokenParser_Filter
    {
    }
}
