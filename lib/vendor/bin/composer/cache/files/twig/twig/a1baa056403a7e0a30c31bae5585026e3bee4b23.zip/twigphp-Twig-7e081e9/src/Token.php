<?php

namespace Twig;

class_exists('Twig_Token');

if (\false) {
    class Token extends \Twig_Token
    {
    }
}
