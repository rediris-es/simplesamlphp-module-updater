<?php

namespace Twig\Node\Expression\Binary;

class_exists('Twig_Node_Expression_Binary_Concat');

if (\false) {
    class ConcatBinary extends \Twig_Node_Expression_Binary_Concat
    {
    }
}
