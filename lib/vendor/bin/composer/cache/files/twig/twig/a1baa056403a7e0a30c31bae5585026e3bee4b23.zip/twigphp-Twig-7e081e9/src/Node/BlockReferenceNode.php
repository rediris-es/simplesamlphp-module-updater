<?php

namespace Twig\Node;

class_exists('Twig_Node_BlockReference');

if (\false) {
    class BlockReferenceNode extends \Twig_Node_BlockReference
    {
    }
}
