<?php

namespace Twig\RuntimeLoader;

class_exists('Twig_FactoryRuntimeLoader');

if (\false) {
    class FactoryRuntimeLoader extends \Twig_FactoryRuntimeLoader
    {
    }
}
