<?php

namespace Twig\Node\Expression\Filter;

class_exists('Twig_Node_Expression_Filter_Default');

if (\false) {
    class DefaultFilter extends \Twig_Node_Expression_Filter_Default
    {
    }
}
