<?php

namespace Twig\Node;

class_exists('Twig_Node_Macro');

if (\false) {
    class MacroNode extends \Twig_Node_Macro
    {
    }
}
