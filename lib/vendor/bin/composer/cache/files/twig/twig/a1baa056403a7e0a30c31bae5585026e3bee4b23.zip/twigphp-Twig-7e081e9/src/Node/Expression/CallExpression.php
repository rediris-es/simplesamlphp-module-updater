<?php

namespace Twig\Node\Expression;

class_exists('Twig_Node_Expression_Call');

if (\false) {
    class CallExpression extends \Twig_Node_Expression_Call
    {
    }
}
