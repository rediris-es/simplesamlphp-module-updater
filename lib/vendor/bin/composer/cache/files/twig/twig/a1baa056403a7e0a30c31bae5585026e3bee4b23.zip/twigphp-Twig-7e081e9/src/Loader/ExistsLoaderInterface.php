<?php

namespace Twig\Loader;

class_exists('Twig_ExistsLoaderInterface');

if (\false) {
    interface ExistsLoaderInterface extends \Twig_ExistsLoaderInterface
    {
    }
}
