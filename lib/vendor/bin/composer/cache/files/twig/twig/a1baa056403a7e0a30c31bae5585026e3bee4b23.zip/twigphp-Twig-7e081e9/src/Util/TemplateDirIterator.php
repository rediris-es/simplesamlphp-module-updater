<?php

namespace Twig\Util;

class_exists('Twig_Util_TemplateDirIterator');

if (\false) {
    class TemplateDirIterator extends \Twig_Util_TemplateDirIterator
    {
    }
}
